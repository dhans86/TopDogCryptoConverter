Instructions: 
1.	Unzip folder and extract it to a location
2.	Open the .py file with IDLE Python 3.0 or higher
3.	Run the .py file with IDLE
4.	First Window is Log in Credentials
5.	Enter in the following for the Username: username
6.	Enter in the following for the Password: password
7.	Message will appear in terminal if either password or username is incorrect
8.	Message in terminal will also so the username and password entered in the window
9.	With the mouse click the ‘X’ on the top right corner if log in credentials were correct
10.	Next Window is the Crypto Converter to Fiat Currency
11.	Drop down on the Crypto Currency to select from (SHIB,DOGE,BTC, or ELON)
12.	Drop down on the Fiat Currency to select from (USD, EUR, or XAU)
13.	Enter in the text box field for crypto currency the amount to convert
14.	Click the ‘Convert’ button
15.	Amount of Fiat currency will appear in the text box
16.	Change the amount of Crypto Currency to convert or drop down to change currencies
17.	Repeat steps until finished
18.	Click ‘Exit’ to end the program

ZipFolder
1.	Make sure to unzip the folder and extract with the txt file and images included
2.	To change or add a different Fiat or Crypto Currency see below 
Text File:
1.	To add or delete a fiat currency or cryptocurrency
2.	Open the txt file ‘cryptocurrency.txt’
3.	Add different cryptos under CRYPTO
4.	Add different fiat’s under FIAT 
5.	Must use symbols correct Currency Symbols for either
6.	See All Cryptocurrencies | CoinMarketCap for list of symbols
